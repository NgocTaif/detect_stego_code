import sys

def compare_dct(file1, file2):
    with open(file1) as f1, open(file2) as f2:
        lines1 = f1.readlines()
        lines2 = f2.readlines()
    
    diff_count = 0
    for i, (a, b) in enumerate(zip(lines1, lines2)):
        if a != b:
            diff_count += 1

    print(f"\nThe total number of different rows between the two matrices: {diff_count}")


input1 = sys.argv[1]
input2 = sys.argv[2]
compare_dct(input1, input2)
